package com.Koolade446.tutorial;

import java.util.List;

import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.world.World;

public class CusSword extends ItemSword {

	public CusSword() {
		super(TutorialMod.sword1);
		// TODO Auto-generated constructor stub
		this.setRegistryName("sword");
		this.setUnlocalizedName("sword");
		this.setCreativeTab(CreativeTabs.COMBAT);
	}
	
	@Override
	public void addInformation(ItemStack itemstack, World world, List<String> list, ITooltipFlag par3) {
		super.addInformation(itemstack, world, list, par3);
		list.add("Fire Aspect X");
	}
	@Override
	public boolean hitEntity(ItemStack itemstack, EntityLivingBase entity, EntityLivingBase entity1) {
		boolean rVal = super.hitEntity(itemstack, entity, entity1);
		int x = (int) entity.posX;
		int y = (int) entity.posY;
		int z = (int) entity.posZ;
		{
			java.util.HashMap<String, Object> $_dependencies = new java.util.HashMap<>();
			$_dependencies.put("entity", entity);
			EntityIsHit.executeProcedure($_dependencies);
		}
		return rVal;
	}
	public boolean hasEffect(ItemStack itemstack) {
		return true;
	}
	

}
