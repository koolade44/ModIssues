package com.Koolade446.tutorial;

import net.minecraft.item.Item;
import net.minecraft.item.Item.ToolMaterial;
import net.minecraftforge.common.util.EnumHelper;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

@Mod(modid = TutorialMod.MODID, name = TutorialMod.NAME, version = TutorialMod.VERSION)
public class TutorialMod
{
    public static final String MODID = "tutorial";
    public static final String NAME = "Tutorial Mod";
    public static final String VERSION = "1.0";

    public static ToolMaterial sword1;
    public static Item sword;

    @EventHandler
    public void preInit(FMLPreInitializationEvent event)
    {
        event.getModLog();
        sword1 = EnumHelper.addToolMaterial("sword", 4, 1000, 20.0f, 8.0f, 300);
        sword = new CusSword();
    }

    @EventHandler
    public void init(FMLInitializationEvent event)
    {}
}
