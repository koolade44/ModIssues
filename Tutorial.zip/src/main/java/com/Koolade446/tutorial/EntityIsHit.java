package com.Koolade446.tutorial;

import net.minecraft.entity.Entity;

public class EntityIsHit {
	public EntityIsHit(EntityIsHit instance) {
		super();
	}
	
	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("EntityIsHit could not be loaded correctly");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		entity.setFire(10);
		
	}
	

}
